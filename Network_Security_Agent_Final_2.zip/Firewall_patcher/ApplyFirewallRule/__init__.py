import azure.functions as func
import logging
import traceback
import json

try:
    from azure.identity import DefaultAzureCredential
    from azure.mgmt.network import NetworkManagementClient
    from azure.mgmt.network.models import SecurityRule
    import os

    logging.info("=== DEBUG MODE ENABLED ===")

    def main(req: func.HttpRequest) -> func.HttpResponse:
        logging.info("[START] ApplyFirewallRule function triggered")

        try:
            headers = dict(req.headers)
            logging.info(f"[HEADERS] Request headers: {headers}")
        except Exception as e:
            logging.error(f"[ERROR] Failed to read headers: {str(e)}")

        # Step 1: Parse JSON body
        try:
            req_body = req.get_json()
            logging.info(f"[BODY] Raw request body: {json.dumps(req_body, indent=2)}")
        except Exception as e:
            logging.error(f"[JSON ERROR] Failed to parse request body: {str(e)}")
            return func.HttpResponse("Invalid JSON body", status_code=400)

        # Step 2: Validate required fields
        required_fields = [
            "nsg_name", "rule_name", "direction", "access",
            "protocol", "source", "destination", "port"
        ]
        missing = [field for field in required_fields if not req_body.get(field)]
        if missing:
            logging.error(f"[VALIDATION ERROR] Missing fields: {missing}")
            return func.HttpResponse(f"Missing required fields: {', '.join(missing)}", status_code=400)

        # Step 3: Load environment variables
        try:
            subscription_id = os.environ.get("AZURE_SUBSCRIPTION_ID")
            resource_group = os.environ.get("AZURE_RESOURCE_GROUP")
            if not subscription_id or not resource_group:
                logging.error("[ENV ERROR] Missing AZURE_SUBSCRIPTION_ID or AZURE_RESOURCE_GROUP")
                return func.HttpResponse("Missing required environment variables", status_code=500)

            logging.info(f"[ENV] Subscription ID: {subscription_id}")
            logging.info(f"[ENV] Resource Group: {resource_group}")
        except Exception as e:
            logging.error(f"[ENV ERROR] Failed to fetch environment variables: {str(e)}")
            return func.HttpResponse("Failed to load environment variables", status_code=500)

        # Step 4: Create Azure client
        try:
            client = NetworkManagementClient(DefaultAzureCredential(), subscription_id)
            logging.info("[AZURE] NetworkManagementClient created successfully")
        except Exception as e:
            logging.error(f"[AZURE ERROR] Failed to create client: {str(e)}")
            return func.HttpResponse("Failed to initialize Azure client", status_code=500)

        # Step 5: Fetch existing NSG rules and compute priority
        try:
            existing_rules = list(client.security_rules.list(resource_group, req_body["nsg_name"]))
            direction = req_body["direction"]
            used_priorities = [rule.priority for rule in existing_rules if rule.direction.lower() == direction.lower()]
            priority = next((p for p in range(100, 4097) if p not in used_priorities), None)

            if priority is None:
                logging.error("[PRIORITY ERROR] No available priority values left.")
                return func.HttpResponse("No available priority values found", status_code=500)

            logging.info(f"[PRIORITY] Assigned priority: {priority}")
        except Exception as e:
            logging.error(f"[PRIORITY ERROR] Failed to calculate priority: {str(e)}")
            return func.HttpResponse("Failed to determine rule priority", status_code=500)

        # Step 6: Build security rule object
        try:
            rule = SecurityRule(
                name=req_body["rule_name"],
                priority=priority,
                direction=direction,
                access=req_body["access"],
                protocol=req_body["protocol"],
                source_address_prefix=req_body["source"],
                destination_address_prefix=req_body["destination"],
                source_port_range="*",
                destination_port_range=str(req_body["port"])
            )
            logging.info("[BUILD] SecurityRule object created")
        except Exception as e:
            logging.error(f"[BUILD ERROR] Failed to build security rule: {str(e)}")
            return func.HttpResponse("Failed to build security rule", status_code=500)

        # Step 7: Apply the rule to NSG
        try:
            logging.info("[APPLY] Initiating rule application...")
            op = client.security_rules.begin_create_or_update(
                resource_group_name=resource_group,
                network_security_group_name=req_body["nsg_name"],
                security_rule_name=req_body["rule_name"],
                security_rule_parameters=rule
            )
            op.result()
            logging.info("[SUCCESS] Rule applied successfully")
            return func.HttpResponse(f"Rule applied successfully with priority {priority}", status_code=200)
        except Exception as e:
            logging.error(f"[APPLY ERROR] {str(e)}")
            logging.error(traceback.format_exc())
            return func.HttpResponse(f"Internal server error while applying rule: {str(e)}", status_code=500)

except Exception as import_error:
    logging.error("[IMPORT ERROR] Function failed during import")
    logging.error(str(import_error))
    logging.error(traceback.format_exc())